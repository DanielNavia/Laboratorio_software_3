<?php
require('vista/inicioSesion.php');
