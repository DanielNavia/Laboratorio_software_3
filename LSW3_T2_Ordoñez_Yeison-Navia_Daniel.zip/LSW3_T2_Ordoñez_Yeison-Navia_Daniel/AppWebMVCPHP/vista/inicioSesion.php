<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Log In</title>
        <link rel="stylesheet" type="text/css" href="vista/css/estilos_1.css">
    </head>
    <body>
        <div id="contenido">
            <center>
                <form action="controlador/gestion.php" method="post">
                    <section class="forma-registro" >
                        <h2>Inicio Sesion</h2>
                        <input class="cbx" type="text" name="usuario" placeholder="Ingrese su usuario">
                        <input class="cbx" type="password" name="clave" placeholder="Ingrese su Clave">
                        <input class="boton" type="submit" value="Log In">
                    </section>
                </form>
            </center>
        </div>
    </body>
</html>
