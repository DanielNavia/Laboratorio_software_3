<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Lista de productos</title>
        <link rel="stylesheet" type="text/css" href="../vista/css/estilos.css">
    </head>
    <body>
        <div id="contenido">
            <center>
                <table class="content-table">
                    <thead>
                        <tr>
                            <th>Código</th>
                            <th>Nombre</th>
                            <th>Precio</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            foreach($lstproductos as $item){
                                echo '<tr>';
                                echo '<td>'.$item["codigo"].'</td>';
                                echo '<td>'.$item["nombre"].'</td>';
                                echo '<td>'.$item["precio"].'</td>';
                                echo '</tr>';
                            }
                        ?>
                    </tbody>
                </table>            
            <section class="forma-forma-registro" >
                <form action="../controlador/gestionInformacion.php">
                    <input class="boton" type="submit" value="Informacion usuarios">
                </form>
            </section>
            <a href="../cerrarsesion.php">Cerrar Sesion</a>
            </center>
        </div>
    </body>
</html>
