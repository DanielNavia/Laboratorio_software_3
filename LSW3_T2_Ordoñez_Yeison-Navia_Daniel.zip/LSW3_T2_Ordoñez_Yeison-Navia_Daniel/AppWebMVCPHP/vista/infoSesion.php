<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Lista de Usuario</title>
        <link rel="stylesheet" type="text/css" href="../vista/css/estilos.css">
    </head>
    <body>
        <div id="contenido">
            <center>
                <table class="content-table">
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Nombre</th>
                            <th>rol</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            foreach($lstusuarios as $item){
                                echo '<tr>';
                                echo '<td>'.$item["usuario"].'</td>';
                                echo '<td>'.$item["nombre"].'</td>';
                                echo '<td>'.$item["rol"].'</td>';
                                echo '</tr>';
                            }
                        ?>
                    </tbody>
                </table>
                <section class="forma-forma-registro" >
                    <form action="../controlador/gestionProducto.php">
                    <input class="boton" type="submit" value="Informacion productos">
                </form>
                </section>
            <a href="../cerrarsesion.php">Cerrar Sesion</a>
            </center>
        </div>
    </body>
</html>
