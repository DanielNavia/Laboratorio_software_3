<?php
require_once('../modelo/clsConexion.php');
/**
 * Description of clsProductoAcceso
 *
 * @author Adrian Mu
 */
class clsProductoAcceso {
    //atributos
    private $conexion;
    
    //metodos
    public function __construct() {
        $this->conexion = new clsConexion();
    }
    public function listar(){
        $sql = 'SELECT * FROM PRODUCTO';
        $consulta = $this->conexion->getConexion()->query($sql);
        $listadoProductos = [];
        $i=0;
        while($fila = $consulta->fetch_assoc()){
            $listadoProductos[$i] = $fila;
            $i++;
        }
        return $listadoProductos;
    }
}
