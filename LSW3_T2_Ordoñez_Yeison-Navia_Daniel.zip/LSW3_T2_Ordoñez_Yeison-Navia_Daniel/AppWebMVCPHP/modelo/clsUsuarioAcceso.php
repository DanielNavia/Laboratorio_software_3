<?php
//Reanuda sesion
session_start();
require '../modelo/clsConexion.php';
/**
 * Description of clsProductoAcceso
 *
 * @author Daniel Navia
 */
class clsUsuarioAcceso {
    //atributos
    private $conexion;
    
    //metodos
    public function __construct() {
        $this->conexion = new clsConexion();
    }
    
    public function listar($usuario){
        $sql = "SELECT * FROM USUARIO WHERE USUARIO = '$usuario'";
        $consulta = $this->conexion->getConexion()->query($sql);
        $listadoUsuario = [];
        $i=0;
        while($fila = $consulta->fetch_assoc()){
            $listadoUsuario[$i] = $fila;
            $i++;
        }
        return $listadoUsuario;
    }
    
    //Realiza la busqueda para iniciar sesion
    public function finiciarSesion($usuario, $clave)
    {     
        $_SESSION['usuario'] = $usuario;
        $sql = "SELECT * FROM USUARIO WHERE USUARIO = '$usuario' AND CLAVE = '$clave'";
        $consulta = $this->conexion->getConexion()->query($sql); 
        $filas = mysqli_num_rows($consulta);
        if($filas > 0)
        {
            require '../productos.php';
        }else 
        {
            echo '<script language="javascript">alert("Error de autentificacion");window.location.href="../index.php"</script>';
        }   
    }
    
    
    
    
    
}