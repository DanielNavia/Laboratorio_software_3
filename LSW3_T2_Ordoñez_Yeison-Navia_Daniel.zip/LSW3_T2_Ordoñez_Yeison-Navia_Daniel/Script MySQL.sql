CREATE DATABASE bdproductos;

CREATE TABLE producto (
  codigo int(11) NOT NULL AUTO_INCREMENT,
  nombre varchar(120) DEFAULT NULL,
  precio decimal(6,2) DEFAULT NULL,
  PRIMARY KEY (codigo)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO producto VALUES (1, 'aceite', 1800.78);
INSERT INTO producto VALUES (2, 'pasta', 3570.52);

CREATE TABLE usuario (
  usuario varchar(120) DEFAULT NULL,
  clave int(120) DEFAULT NULL,
  nombre varchar(120) DEFAULT NULL,
  rol varchar(120) DEFAULT NULL,
  PRIMARY KEY (usuario)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO usuario VALUES ('DanielN21', 123, 'Daniel', 'admin');
INSERT INTO usuario VALUES ('FelipeN22', 124, 'Felipe', 'admin');
INSERT INTO usuario VALUES ('ManuelN23', 125, 'Manuel', 'no-admin');
INSERT INTO usuario VALUES ('AndresN24', 126, 'Andres', 'no-admin');
INSERT INTO usuario VALUES ('AndreaN26', 128, 'Andrea', 'no-admin');
INSERT INTO usuario VALUES ('Yeisordo27', 129, 'Yesion', 'no-admin');
INSERT INTO usuario VALUES ('LuisaN21', 112, 'Luisa', 'no-admin');
INSERT INTO usuario VALUES ('FernandaN60', 113, 'Fernanda', 'no-admin');
INSERT INTO usuario VALUES ('LauraN61', 116, 'Laura', 'no-admin');
INSERT INTO usuario VALUES ('LinaN29', 133, 'Lina', 'no-admin');
INSERT INTO usuario VALUES ('JulianaN28', 135, 'Juliana', 'no-admin');
INSERT INTO usuario VALUES ('CarlosN73', 143, 'Carlos', 'no-admin');